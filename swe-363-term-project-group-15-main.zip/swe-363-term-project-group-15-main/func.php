<?php
function e($v){
    return htmlspecialchars($v,ENT_QUOTES,'UTF-8');
}